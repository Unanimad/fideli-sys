var COMPANY = new Object;

COMPANY.token = "6576675c72dee038a2c6500e84359fca748465b1";
COMPANY.theme = "theme-orange";
COMPANY.layout = "layout-dark";